# Changes in 2.1.1 #
Lanterna 2.1.1 is a minor bugfix release and re-adding some methods that has been lost going from 2.0 to 2.1

  * `Panel.setBetweenComponentsPadding` has returned (as deprecated)
  * Owner Window can now be correctly derived from a component
  * `GUIScreen.closeWindow()` has returned (as deprecated)
  * Classes extending `AbstractListBox` now follow the preferred size override correctly

For a more complete list of changes, please click on the Source tab above and browse the changesets.