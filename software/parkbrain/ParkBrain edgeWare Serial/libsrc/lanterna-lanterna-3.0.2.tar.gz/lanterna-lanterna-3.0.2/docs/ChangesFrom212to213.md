# Changes in 2.1.3 #
Lanterna 2.1.3 is a minor bugfix release with a few enhancements

  * Expanded Table API
  * Improved (but still incomplete) CJK character handling
  * OS X input compatibility fix
  * More input key combinations detecting ALT down
  * Screen padding character can be customized
  * Background color fix with Screen

For a more complete list of changes, please click on the Source tab above and browse the changesets.