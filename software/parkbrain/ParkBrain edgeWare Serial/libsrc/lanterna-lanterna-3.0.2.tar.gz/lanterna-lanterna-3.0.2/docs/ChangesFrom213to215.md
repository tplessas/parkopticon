# Changes in 2.1.5 #
Lanterna 2.1.5 is a minor bugfix release with a few enhancements

  * New method invalidate the Screen buffer and force a complete redraw
  * Visibility changes on GUIScreen to make it easier to extend

For a more complete list of changes, please click on the Source tab above and browse the changesets.