# Changes in 2.1.8 #
Lanterna 2.1.8 is a minor bugfix release with a few enhancements

  * Adding a file dialog component
  * Adding method to make it easier to wrap components in a border
  * SwingTerminal function key support
  * Input focus bug fixes
  * InputDecoder fixes backported from master branch
  * Can set fill character of TextBox (other than space)
  * Window-deriving classes can inspect which component has input focus
  * Can turn off shadows for windows

For a more complete list of changes, please click on the Source tab above and browse the changesets.