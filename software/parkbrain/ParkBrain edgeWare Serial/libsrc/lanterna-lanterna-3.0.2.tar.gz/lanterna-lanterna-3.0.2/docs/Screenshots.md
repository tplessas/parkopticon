Windows 10 running Lanterna in the Swing terminal emulator:
![http://mabe02.github.io/lanterna/resources/screenshots/win10-screenshot.png](http://mabe02.github.io/lanterna/resources/screenshots/win10-screenshot.png)

Xubuntu running Lanterna in the Swing terminal emulator:
TBD

Mac OS X running Lanterna in the Swing terminal emulator:
TBD

Xubuntu running Lanterna in the Swing terminal emulator:
TBD

Xubuntu running Lanterna in the Swing terminal emulator:
TBD